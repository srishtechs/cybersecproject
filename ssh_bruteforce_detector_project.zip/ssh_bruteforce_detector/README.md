# SSH Sentinel — SSH Brute-Force Detection Dashboard

A local Flask website that analyses Linux SSH authentication logs, records failed password events in SQLite, and alerts when one source IP has at least 5 failures within 10 minutes.

## Requirements
- Python 3.10 or newer
- Visual Studio Code
- VS Code Python extension

## Windows setup
1. Extract this ZIP file.
2. Open the `ssh_bruteforce_detector` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:
   `py -m venv .venv`
5. Activate it in PowerShell:
   `.venv\Scripts\Activate.ps1`
   If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.
6. Install dependencies:
   `py -m pip install -r requirements.txt`
7. Start the website:
   `py app.py`
8. Open `http://127.0.0.1:5000` in your browser.
9. Click **Load sample data** to see example events and an alert.

## Linux / macOS setup
1. Open this folder in VS Code.
2. Create a virtual environment: `python3 -m venv .venv`
3. Activate it: `source .venv/bin/activate`
4. Install: `python3 -m pip install -r requirements.txt`
5. Run: `python3 app.py`
6. Open `http://127.0.0.1:5000`.

## Use real logs
On an Ubuntu/Debian machine, SSH authentication logs are commonly in `/var/log/auth.log`. On some distributions they are in `/var/log/secure` or available through the system journal. Copy an authorised log file to your development computer, then upload it using the dashboard. Do not upload logs containing secrets or personal information to a public service.

## Detection logic
- Parses common `sshd: Failed password for ... from IP ...` messages.
- Groups failed password events by source IP.
- Creates an alert for 5 or more events in a rolling 10-minute window.
- Stores events and alerts in `ssh_detector.db`.

## Important limitations
- This is a local educational prototype, not a production SIEM.
- It analyses uploaded files and the bundled sample; it does not continuously monitor a server.
- Syslog timestamps omit the year and timezone, so the app assigns the current computer year and local time.
- The included sample uses documentation-only IP ranges; they are not real attacker addresses.
- The server binds to 127.0.0.1 so it is accessible only from this computer.
