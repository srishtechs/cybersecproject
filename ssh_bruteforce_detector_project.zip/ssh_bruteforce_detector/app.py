from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict
import sqlite3
import re
import os

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "ssh_detector.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "local-dev-change-this-key")
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB
ALLOWED_EXTENSIONS = {".log", ".txt"}
THRESHOLD = 5
WINDOW_MINUTES = 10

# Common Linux sshd messages in /var/log/auth.log or /var/log/secure.
FAILED_RE = re.compile(
    r"Failed password for (?:invalid user )?(?P<username>\S+) "
    r"from (?P<ip>[0-9a-fA-F:.]+) port \d+"
)
INVALID_USER_RE = re.compile(
    r"Invalid user (?P<username>\S+) from (?P<ip>[0-9a-fA-F:.]+)"
)
TIMESTAMP_RE = re.compile(
    r"^(?P<month>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+"
    r"(?P<time>\d{2}:\d{2}:\d{2})"
)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_time TEXT NOT NULL,
                ip TEXT NOT NULL,
                username TEXT NOT NULL,
                source_file TEXT NOT NULL,
                raw_line TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                window_start TEXT NOT NULL,
                window_end TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(ip, window_start, window_end)
            )
        """)

def parse_timestamp(line):
    """Parse standard syslog timestamps such as 'Nov 21 00:10:03'."""
    match = TIMESTAMP_RE.match(line)
    if not match:
        return datetime.now()
    try:
        month = datetime.strptime(match.group("month"), "%b").month
        day = int(match.group("day"))
        time_part = datetime.strptime(match.group("time"), "%H:%M:%S").time()
        now = datetime.now()
        return datetime(now.year, month, day, time_part.hour, time_part.minute, time_part.second)
    except ValueError:
        return datetime.now()

def extract_failed_event(line):
    match = FAILED_RE.search(line)
    if match:
        return match.group("ip"), match.group("username")
    # Invalid-user messages are useful context, but only count a failed
    # password event when the log line explicitly says "Failed password".
    return None

def analyse_lines(lines, source_name):
    parsed = []
    for line in lines:
        event = extract_failed_event(line)
        if event:
            ip, username = event
            parsed.append({
                "time": parse_timestamp(line),
                "ip": ip,
                "username": username,
                "raw": line.strip()[:1000]
            })

    if not parsed:
        return 0, 0

    with get_db() as conn:
        for item in parsed:
            conn.execute(
                """INSERT INTO events (event_time, ip, username, source_file, raw_line)
                   VALUES (?, ?, ?, ?, ?)""",
                (item["time"].isoformat(sep=" "), item["ip"], item["username"],
                 source_name, item["raw"])
            )

        # Evaluate each event against the preceding time window.
        by_ip = defaultdict(list)
        for item in parsed:
            by_ip[item["ip"]].append(item["time"])

        new_alerts = 0
        for ip, times in by_ip.items():
            times.sort()
            for end_time in times:
                start_time = end_time - timedelta(minutes=WINDOW_MINUTES)
                count = sum(start_time <= t <= end_time for t in times)
                if count >= THRESHOLD:
                    start_text = start_time.isoformat(sep=" ")
                    end_text = end_time.isoformat(sep=" ")
                    cursor = conn.execute(
                        """INSERT OR IGNORE INTO alerts
                           (ip, window_start, window_end, attempts, message, created_at)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (ip, start_text, end_text, count,
                         f"{count} failed SSH login attempts within {WINDOW_MINUTES} minutes",
                         datetime.now().isoformat(sep=" "))
                    )
                    new_alerts += cursor.rowcount
        return len(parsed), new_alerts

@app.route("/", methods=["GET"])
def index():
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        unique_ips = conn.execute("SELECT COUNT(DISTINCT ip) FROM events").fetchone()[0]
        alert_count = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
        recent_events = conn.execute(
            "SELECT * FROM events ORDER BY id DESC LIMIT 20"
        ).fetchall()
        alerts = conn.execute(
            "SELECT * FROM alerts ORDER BY id DESC LIMIT 20"
        ).fetchall()
        top_ips = conn.execute(
            """SELECT ip, COUNT(*) AS attempts FROM events
               GROUP BY ip ORDER BY attempts DESC LIMIT 10"""
        ).fetchall()
    return render_template(
        "index.html", total=total, unique_ips=unique_ips,
        alert_count=alert_count, recent_events=recent_events,
        alerts=alerts, top_ips=top_ips,
        threshold=THRESHOLD, window=WINDOW_MINUTES
    )

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("logfile")
    if not file or not file.filename:
        flash("Choose a .log or .txt file first.", "error")
        return redirect(url_for("index"))

    safe_name = secure_filename(file.filename)
    if Path(safe_name).suffix.lower() not in ALLOWED_EXTENSIONS:
        flash("Only .log and .txt files are accepted.", "error")
        return redirect(url_for("index"))

    try:
        content = file.read().decode("utf-8", errors="replace")
        lines = content.splitlines()
        count, alerts = analyse_lines(lines, safe_name)
        flash(f"Analysis complete: {count} failed login events imported; {alerts} new alert(s) generated.", "success")
    except Exception as exc:
        app.logger.exception("Log analysis failed")
        flash(f"Could not analyse that file: {exc}", "error")
    return redirect(url_for("index"))

@app.route("/load-sample", methods=["POST"])
def load_sample():
    sample_path = BASE_DIR / "sample_auth.log"
    if not sample_path.exists():
        flash("Sample log file is missing.", "error")
        return redirect(url_for("index"))
    count, alerts = analyse_lines(
        sample_path.read_text(encoding="utf-8").splitlines(),
        "sample_auth.log"
    )
    flash(f"Sample loaded: {count} failed login events imported; {alerts} new alert(s) generated.", "success")
    return redirect(url_for("index"))

@app.route("/clear", methods=["POST"])
def clear_data():
    with get_db() as conn:
        conn.execute("DELETE FROM events")
        conn.execute("DELETE FROM alerts")
    flash("Local dashboard data cleared.", "success")
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    # Localhost only: this website is not exposed to your network.
    app.run(host="127.0.0.1", port=5000, debug=False)
